package org.scoula;

import org.springframework.stereotype.Component;

@Component
public class Chef {
}
